$(document).ready(function() {
    $('#submitButton').click(function() {
        $('form.xenForm.section').submit();
    })
})