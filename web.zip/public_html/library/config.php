<?php

$config['db']['host'] = 'localhost';
$config['db']['port'] = '3306';
$config['db']['username'] = '';
$config['db']['password'] = '';
$config['db']['dbname'] = '';


$config['superAdmins'] = '1';
