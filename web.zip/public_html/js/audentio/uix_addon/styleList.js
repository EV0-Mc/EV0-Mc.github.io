$(document).ready(function()
{
    $('.adStyle .toggler').remove();
    $('.adStyle .secondaryContent:not(.delete)').remove();
});